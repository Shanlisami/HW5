//Shanli Samienezhad 40223042

#include <stdio.h>

int main()
{
    int n;
    printf("Number of characters in string:");
    scanf("%d", &n);

    char A[n];
    printf("String:");
    scanf("%s", A);

    if( A[1] == '\0' )
    {
        printf("%s\n", A);
    }

    int i = 0 , k;

    while(A[i])
    {
        if( A[i] != A[i+1] )
        {
            i++;
        }

        else
        {
            for( k = i ; k < n ; k++ )
            {
                A[k] = A[k+2];
            }
                
            printf("%s\n", A);
            i = 0;
        }
    }
}